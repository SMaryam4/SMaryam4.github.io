-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2025 at 05:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pak_cricket`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE `blog_comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog_comments`
--

INSERT INTO `blog_comments` (`id`, `post_id`, `comment`, `created_at`) VALUES
(1, 1, 'helo', '2025-07-28 11:49:43'),
(2, 1, 'ddffdsffghgsdsgfv', '2025-07-28 12:23:26');

-- --------------------------------------------------------

--
-- Table structure for table `blog_likes`
--

CREATE TABLE `blog_likes` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_ip` varchar(45) NOT NULL,
  `reaction` enum('like','love','funny','wow','sad','angry') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog_likes`
--

INSERT INTO `blog_likes` (`id`, `post_id`, `user_ip`, `reaction`, `created_at`) VALUES
(1, 1, '::1', 'wow', '2025-07-28 11:49:34');

-- --------------------------------------------------------

--
-- Table structure for table `blog_posts`
--

CREATE TABLE `blog_posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog_posts`
--

INSERT INTO `blog_posts` (`id`, `title`, `content`, `created_at`) VALUES
(1, 'pakistan won the match', 'hjddjwdewnduwewdbwukewhdjmdewuiewdjdewhghjewn diuewkwnd', '2025-07-28 11:46:33'),
(2, 'jhfduibjehyujen', 'hhhhhhhhhhhhuehfdnceyuhnxuejddddddddddddddddddksssssssssssnccccccccccccccccueeeeeeeeeecnnnnnnnnnnnnnnnnsjjjjjjjjjjjjjjjjjjjjjieeeeeeeeeeeksmxncsssssssssssssssssssssssssskkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkwwwwwwwwwwwwwwwwwwwwwwwwwwoooooooooooooooooooooooooooooooooooooooooooooooooooooosssssssssssssssssssssssssssmmmmmmmmmmmmmmmmmffffffffffffffffffff', '2025-07-28 12:35:17');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `parent_comment_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `detail` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `description`, `image_url`, `detail`, `created_at`) VALUES
(1, 'Shaheen Afridi shines in Test series!', 'Shaheen takes 10 wickets in the 2nd Test match against India.', 'https://example.com/shaheen.jpg', 'In a thrilling Test match, Shaheen Afridi took 10 wickets...', '2025-07-26 05:50:48'),
(3, 'babar azam', 'can babar azam breaks the record of kohli', '', 'hdsjafiufddfladhdvbkjsudwdasdhiurefdsjdjdk', '2025-07-27 08:42:04'),
(4, 'hfejfhek', 'hfkrefrkfr', '', 'jeefkfref', '2025-07-27 08:42:15'),
(5, 'hjdshckjd', 'dejkhe', '', 'jdelreirfrekf', '2025-07-27 08:44:09'),
(6, 'dfdccsdf', 'ddfd', '', 'df', '2025-07-27 08:45:31');

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(255) NOT NULL,
  `matches` int(11) DEFAULT 0,
  `runs` int(11) DEFAULT 0,
  `nationality` varchar(100) NOT NULL,
  `role` varchar(50) DEFAULT NULL,
  `team` varchar(100) DEFAULT NULL,
  `featured` tinyint(1) DEFAULT 0,
  `star_player` tinyint(1) DEFAULT 0,
  `born` varchar(100) DEFAULT NULL,
  `major_teams` varchar(255) DEFAULT NULL,
  `batting_style` varchar(100) DEFAULT NULL,
  `bowling_style` varchar(100) DEFAULT NULL,
  `overview` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`id`, `name`, `image`, `matches`, `runs`, `nationality`, `role`, `team`, `featured`, `star_player`, `born`, `major_teams`, `batting_style`, `bowling_style`, `overview`) VALUES
(1, 'Babar Azam', 'babar azam.jpg', 270, 11000, '0', 'Batter', 'pakistan', 0, 0, '5', 'pakitsan,peshawar zalmi', 'right handed batsman', 'right arm', 'babar azam is pakitani player born in pakitan lahore'),
(2, 'Shaheen Afridi', 'shaheen afridi.jpg', 130, 200, 'Pakistan', NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL),
(3, 'Mohammad Rizwan', 'rizwan.jpeg', 150, 4800, 'Pakistan', NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL),
(4, 'Shadab Khan', 'shadab khan.jpg', 140, 2300, 'Pakistan', NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL),
(5, 'Fakhar Zaman', 'fakhar zaman.jpg', 160, 5100, 'Pakistan', NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, NULL),
(6, 'Muhammad Haris', 'muhammad haris.jpg', 0, 0, 'Pakistan', NULL, NULL, 0, 0, '15 October 1994', 'Pakistan, Karachi Kings', 'Right-hand bat', 'Right-arm offbreak', NULL),
(7, 'usman khan', 'sufiyan zalmi.jpg', 10, 2459, '0', 'batsman', 'pakistan', 1, 1, '1989', '', 'right handed', 'right arm fast bowler', ''),
(8, 'Naseem Shah', 'Wood zalmi.jpg', 45, 1179, '0', 'bowler', 'pakistan', 1, 1, '8', 'pakistan In psl islamabad united', 'right arm fast bowler', 'right arm fast bowler', ''),
(9, 'shadab khan', 'shadab khan.jpg', 59, 1567, '0', 'bowler', 'pakitsan', 1, 0, '1995', 'pakitsan,islamabad united', 'right handed', 'spinner', ''),
(10, 'haris rauf', 'Shaheen afridi.jpg', 89, 2723, '0', 'bowler', 'pakitsan', 0, 1, '1989', 'pakistan ,lahore qalander', 'right arm fast bowler', 'right arm fast bowler', '');

-- --------------------------------------------------------

--
-- Table structure for table `player_stats`
--

CREATE TABLE `player_stats` (
  `id` int(11) NOT NULL,
  `player_id` int(11) DEFAULT NULL,
  `format` enum('T20','ODI','Test') DEFAULT NULL,
  `matches` int(11) DEFAULT 0,
  `innings` int(11) DEFAULT 0,
  `runs` int(11) DEFAULT 0,
  `wickets` int(11) DEFAULT 0,
  `strike_rate` float DEFAULT 0,
  `average` float DEFAULT 0,
  `hundreds` int(11) DEFAULT 0,
  `fifties` int(11) DEFAULT 0,
  `ducks` int(11) DEFAULT 0,
  `sixes` int(11) DEFAULT 0,
  `fours` int(11) DEFAULT 0,
  `highest_score` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `player_stats`
--

INSERT INTO `player_stats` (`id`, `player_id`, `format`, `matches`, `innings`, `runs`, `wickets`, `strike_rate`, `average`, `hundreds`, `fifties`, `ducks`, `sixes`, `fours`, `highest_score`) VALUES
(2, 1, 'ODI', 110, 108, 5400, 8, 89.4, 57, 17, 23, 4, 120, 310, 158),
(3, 1, 'Test', 50, 90, 3900, 12, 55.2, 48.3, 8, 14, 3, 70, 190, 143),
(6, 1, NULL, 90, 0, 5678, 34, 140, 60, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `media_path` varchar(255) DEFAULT NULL,
  `media_type` enum('image','video') DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `is_admin_post` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `psl_matches`
--

CREATE TABLE `psl_matches` (
  `id` int(11) NOT NULL,
  `team_1` int(11) DEFAULT NULL,
  `team_2` int(11) DEFAULT NULL,
  `match_date` date DEFAULT NULL,
  `match_time` time DEFAULT NULL,
  `stadium` varchar(255) DEFAULT NULL,
  `result` varchar(255) DEFAULT NULL,
  `status` enum('upcoming','completed') DEFAULT 'upcoming'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `psl_matches`
--

INSERT INTO `psl_matches` (`id`, `team_1`, `team_2`, `match_date`, `match_time`, `stadium`, `result`, `status`) VALUES
(1, 1, 2, '2025-07-28', '14:00:00', 'karachi cricket stadium', '', 'upcoming'),
(2, 1, 1, '2025-07-30', '11:22:00', 'arbab niaz cricket stadium peshawar', 'peshawar zalmi won by 6 wickets', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `psl_players`
--

CREATE TABLE `psl_players` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL,
  `batting_style` varchar(100) DEFAULT NULL,
  `bowling_style` varchar(100) DEFAULT NULL,
  `nationality` varchar(100) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `matches` int(11) DEFAULT NULL,
  `runs` int(11) DEFAULT NULL,
  `wickets` int(11) DEFAULT NULL,
  `strike_rate` float DEFAULT NULL,
  `average` float DEFAULT NULL,
  `fifties` int(11) DEFAULT NULL,
  `hundreds` int(11) DEFAULT NULL,
  `sixes` int(11) DEFAULT NULL,
  `fours` int(11) DEFAULT NULL,
  `highest_score` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `psl_players`
--

INSERT INTO `psl_players` (`id`, `name`, `image`, `team_id`, `role`, `batting_style`, `bowling_style`, `nationality`, `age`, `matches`, `runs`, `wickets`, `strike_rate`, `average`, `fifties`, `hundreds`, `sixes`, `fours`, `highest_score`) VALUES
(1, 'Babar Azam', 'babar zalmi.jpg', 1, 'Captain', 'Right-hand bat', 'Right-arm offbreak', 'Pakistan', 29, 85, 2935, 0, 130.45, 45.3, 26, 5, 85, 312, 115),
(3, 'Mohammad Haris', 'haris zalmi.jpg', 1, 'Wicket-keeper Batsman', 'Right-hand bat', 'N/A', 'Pakistan', 23, 35, 762, 0, 142.2, 32.7, 5, 1, 40, 89, 86),
(6, 'Tom Kohler-Cadmore', 'tom zalmi.jpg', 1, 'Batsman', 'Right-hand bat', 'N/A', 'England', 29, 30, 798, 0, 138.5, 31.8, 6, 1, 52, 74, 92),
(7, 'Mohammad Rizwan', 'rizwan.jpg', 2, 'Captain ', 'Right-hand bat', 'Right-arm medium', 'Pakistan', 32, 75, 2200, 0, 128.5, 45.2, 16, 1, 85, 190, 104),
(8, 'Shan Masood', 'shan_masood.jpg', 2, 'Batsman', 'Left-hand bat', 'Right-arm medium', 'Pakistan', 33, 60, 1650, 2, 119.3, 30.2, 11, 0, 50, 140, 88),
(9, 'Kieron Pollard', 'ihsan zalmi.jpg', 1, 'All-rounder', 'Right-hand bat', 'Right-arm medium-fast', 'West Indies', 37, 95, 2150, 56, 145.8, 32.8, 10, 3, 112, 186, 109),
(10, 'Ihsanullah', 'ihsanullah.jpg', 2, 'Bowler', 'Right-hand bat', 'Right-arm fast', 'Pakistan', 21, 32, 120, 47, 98.2, 12.5, 0, 0, 9, 15, 20),
(13, 'Saim Ayub', 'saim zalmi.jpg', 1, 'Batsman', 'Left handed batter', 'Right arm offbreak', 'Pakistan', 23, 89, 2297, 10, 143.29, NULL, NULL, 3, 115, 234, 98),
(14, 'babar azam', '1753640665_1753541879_Babar zalmi.jpg', 1, 'batsman', 'right handed', 'right arm', 'Pakistan', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `psl_points`
--

CREATE TABLE `psl_points` (
  `id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `matches` int(11) DEFAULT 0,
  `wins` int(11) DEFAULT 0,
  `losses` int(11) DEFAULT 0,
  `ties` int(11) DEFAULT 0,
  `no_result` int(11) DEFAULT 0,
  `points` int(11) DEFAULT 0,
  `nrr` decimal(5,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `psl_points`
--

INSERT INTO `psl_points` (`id`, `team_id`, `matches`, `wins`, `losses`, `ties`, `no_result`, `points`, `nrr`) VALUES
(1, 1, 5, 3, 2, 0, 0, 6, 0.45);

-- --------------------------------------------------------

--
-- Table structure for table `psl_teams`
--

CREATE TABLE `psl_teams` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `page_link` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `psl_teams`
--

INSERT INTO `psl_teams` (`id`, `name`, `logo`, `page_link`) VALUES
(1, 'Peshawar Zalmi', 'peshawar zalmi.jpg', 'zalmi.php'),
(2, 'Multan Sultans', 'multan sultan.jpg', 'multan_sultans.php'),
(3, 'Lahore Qalandars', 'lahore.png', 'lahore_qalanders.php'),
(4, 'Karachi Kings', '1753632991_karachi.jpg', 'karachi_kings.php'),
(5, 'Quetta Gladiators', '1753633482_quetta.jpg', 'quetta_gladiators.php'),
(6, 'Islamabad United', '1753633037_islamabad.jpg', 'islamabad_united.php');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `created_at`) VALUES
(1, 'hello how are you people. welcome to my website', '2025-07-26 07:13:28'),
(2, 'welcome to this app', '2025-07-26 07:18:17'),
(4, 'hello', '2025-07-26 07:34:59');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `id` int(11) NOT NULL,
  `match_date` date NOT NULL,
  `time` varchar(10) NOT NULL,
  `team1` varchar(100) NOT NULL,
  `team2` varchar(100) NOT NULL,
  `team1_flag` varchar(255) DEFAULT NULL,
  `team2_flag` varchar(255) DEFAULT NULL,
  `venue` varchar(255) NOT NULL,
  `series_name` varchar(255) NOT NULL,
  `result` text DEFAULT NULL,
  `status` enum('upcoming','completed') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id`, `match_date`, `time`, `team1`, `team2`, `team1_flag`, `team2_flag`, `venue`, `series_name`, `result`, `status`) VALUES
(1, '2025-08-05', '19:00', 'Pakistan', 'India', '/flags/pk.png', '/flags/in.png', 'Gaddafi Stadium', 'India tour of Pakistan', NULL, 'upcoming'),
(2, '2025-07-20', '18:00', 'Pakistan', 'England', '/flags/pk.png', '/flags/eng.png', 'National Stadium', 'England tour of Pakistan', 'Pakistan won by 5 wickets', 'completed'),
(4, '2025-08-12', '13:30', 'Australia', 'New Zealand', '/flags/au.png', '/flags/nz.png', 'MCG', 'Trans-Tasman Trophy', '', 'completed'),
(7, '2025-07-15', '18:00', 'Pakistan', 'England', '/flags/pk.png', '/flags/gb.png', 'National Stadium', 'England tour of Pakistan', 'Pakistan won by 5 wickets', 'completed'),
(8, '2025-07-12', '14:00', 'India', 'Australia', '/flags/in.png', '/flags/au.png', 'Wankhede Stadium', 'Australia tour of India', 'Australia won by 3 runs', 'completed'),
(9, '2025-07-05', '11:00', 'New Zealand', 'South Africa', '/flags/nz.png', '/flags/za.png', 'Eden Park', 'SA tour of NZ', 'Match tied', 'completed'),
(10, '2025-07-01', '17:00', 'Bangladesh', 'Afghanistan', '/flags/bd.png', '/flags/af.png', 'Dhaka Stadium', 'Afghanistan tour of Bangladesh', 'Bangladesh won by 2 wickets', 'completed'),
(11, '2025-07-31', '2:30PM', 'pakisrtan', 'india', 'babar zalmi.jpg', 'babar zalmi.jpg', 'lords cricket stadium', 'rtet', '', 'upcoming'),
(13, '2025-07-31', '2:30PM', 'pakisrtan', 'india', 'babar zalmi.jpg', 'babar zalmi.jpg', 'lords cricket stadium', 'rtet', '', 'upcoming'),
(14, '2025-07-22', '2:30PM', 'pakisrtan', 'Sri Lanka', '', '', 'lords cricket stadium', '', '', 'upcoming'),
(15, '2025-07-24', '16:00', 'Bangladesh', 'Sri Lanka', '', '', 'Sher-e-Bangla Stadium', '', '', 'upcoming'),
(16, '2025-07-09', '2:30PM', 'Bangladesh', 'india', '', '', 'lords cricket stadium', '', '', 'upcoming'),
(17, '2025-06-29', '2:30PM', 'afghanistan', 'Sri Lanka', '', '', 'Sher-e-Bangla Stadium', '', '', 'upcoming');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `profile_image`) VALUES
(4, 'sayyedamaryam4', 'maryamsyed2963@gmail.com', '12345', 'user', ''),
(7, 'alisha', 'maryamsyed2963@gmail.com', '$2y$10$ZRTa7UJ79N0.uoYauPJnOef/RoQkYsgYLBYT7OHxRVafYGwj0OE3e', 'admin', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog_comments`
--
ALTER TABLE `blog_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `blog_likes`
--
ALTER TABLE `blog_likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_reaction` (`post_id`,`user_ip`);

--
-- Indexes for table `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `parent_comment_id` (`parent_comment_id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `player_stats`
--
ALTER TABLE `player_stats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `player_id` (`player_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `psl_matches`
--
ALTER TABLE `psl_matches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `psl_players`
--
ALTER TABLE `psl_players`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `psl_points`
--
ALTER TABLE `psl_points`
  ADD PRIMARY KEY (`id`),
  ADD KEY `team_id` (`team_id`);

--
-- Indexes for table `psl_teams`
--
ALTER TABLE `psl_teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog_comments`
--
ALTER TABLE `blog_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `blog_likes`
--
ALTER TABLE `blog_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog_posts`
--
ALTER TABLE `blog_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `player_stats`
--
ALTER TABLE `player_stats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `psl_matches`
--
ALTER TABLE `psl_matches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `psl_players`
--
ALTER TABLE `psl_players`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `psl_points`
--
ALTER TABLE `psl_points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `psl_teams`
--
ALTER TABLE `psl_teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blog_comments`
--
ALTER TABLE `blog_comments`
  ADD CONSTRAINT `blog_comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `blog_posts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `blog_likes`
--
ALTER TABLE `blog_likes`
  ADD CONSTRAINT `blog_likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `blog_posts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`parent_comment_id`) REFERENCES `comments` (`id`);

--
-- Constraints for table `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  ADD CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `player_stats`
--
ALTER TABLE `player_stats`
  ADD CONSTRAINT `player_stats_ibfk_1` FOREIGN KEY (`player_id`) REFERENCES `players` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `psl_points`
--
ALTER TABLE `psl_points`
  ADD CONSTRAINT `psl_points_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `psl_teams` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
